package com.example.luncene;

import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;



public class TextQuery {
	
	public static void main (String[] args){
		query("���Ľ���");
	}
	
	public  static List<Document> query(String query_text) {
		List<Document> list = new ArrayList<>();
		Directory dir = null;
		IndexReader reader = null;
		String frament = null;		
		try {
			Analyzer a = new StandardAnalyzer();
			dir = FSDirectory.open(Paths.get("D:/Users/han/workspace/novel_retrievalWeb/my_searcher/index"));
			reader = DirectoryReader.open(dir);
			IndexSearcher is = new IndexSearcher(reader);
			QueryParser parser = new QueryParser("name", a);
			Query query = parser.parse(query_text);
			//���ƶ����������5��
			TopDocs topDocs = is.search(query, 40);
			
			Highlighter hl = new Highlighter(new QueryScorer(query)); 
			System.out.println("�ܹ�ƥ����ٸ���" + topDocs.totalHits);
			ScoreDoc[] hits = topDocs.scoreDocs;
			// Ӧ����topDocs.totalHits��ͬ
			System.out.println("���������ݣ�" + hits.length);
			for (ScoreDoc scoreDoc : hits) {
				System.out.println("----------------------------");
			    System.out.println("ƥ��÷֣�" + scoreDoc.score);

			    System.out.println("�ĵ�����ID��" + scoreDoc.doc);

			    Document document = is.doc(scoreDoc.doc);
			    
			    list.add(document);
			    
			    String id=(document.get("name"));

			    String question=(document.get("author"));
			    
			    String answer=(document.get("publisher"));

//			    TokenStream ts = a.tokenStream("question", new StringReader(question));  
//		        
//				try {
//					frament = hl.getBestFragment(ts, question);
//										
//				} catch (InvalidTokenOffsetsException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}				
				System.out.println("������"+id);
				System.out.println("���ߣ�"+question);
				System.out.println("�����̣�"+answer);
//		        System.out.println(frament);
			   
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
        try {
			reader.close();
			dir.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
        return list;
	}
}
