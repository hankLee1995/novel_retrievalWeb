package com.example.luncene;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import com.example.dao.BookDao;
import com.example.entity.Book;


public class TextIndex {
	public   static   void  main(String[] args)  throws  Exception  {   
           BookDao bdao = new BookDao();
           indexBook(bdao.queryAll());
           
   } 
	
	public static void indexBook(List<Book> list) throws  Exception{
	       Analyzer luceneAnalyzer  =   new  StandardAnalyzer();  
	       Directory dir = FSDirectory.open(Paths.get("./my_searcher/index"));
	       IndexWriterConfig iwc = new IndexWriterConfig(luceneAnalyzer);
	       IndexWriter indexWriter  = new IndexWriter(dir, iwc);
	       
	       long  startTime  =   new  Date().getTime(); 
	       for(Book b : list){
               Document document  =   new  Document();   
               Field FieldId  =   new TextField ( "id" , b.getId(),   
                       Field.Store.YES);  
               Field FieldName  =   new  TextField( "name" , b.getName(),   
                       Field.Store.YES);
               Field FieldAuthor =   new  TextField( "author" , b.getAuthor(), Field.Store.YES);   
               Field FieldPublisher  =   new  TextField( "publisher" , b.getPublisher(), Field.Store.YES); 
               Field FieldPublicTime  =   new  TextField( "publicTime" , b.getPublicTime(), Field.Store.YES);
               Field FieldScore  =   new  TextField( "score" , String.valueOf(b.getScore()), Field.Store.YES);
               Field FieldCount  =   new  TextField( "count" , String.valueOf(b.getCount()), Field.Store.YES);
               Field FieldContent_brief  =   new  TextField( "content_brief" , b.getContent_brief(), Field.Store.YES);
               Field FieldAuthor_brief  =   new  TextField( "author_brief" , b.getAuthor_brief(), Field.Store.YES);
               
               document.add(FieldId);   
               document.add(FieldName); 
               document.add(FieldAuthor);   
               document.add(FieldPublisher);   
               document.add(FieldPublicTime); 
               document.add(FieldScore);   
               document.add(FieldCount);
               document.add(FieldContent_brief);   
               document.add(FieldAuthor_brief);
               indexWriter.addDocument(document);
	       }
	       indexWriter.close();
	        // ����һ��������ʱ��    
	       long  endTime  =   new  Date().getTime();   
	       System.out   
	               .println( "�⻨���� "   
	                        +  (endTime  -  startTime)   
	                        +   " �����������ݿ�����ӵ���������ȥ! "); 
	}
	
	public static void indexFile() throws  Exception{
        /*  ָ��Ҫ�����ļ��е�λ��,�ŵ��˹���Ŀ¼��my_searcher��S�ļ�����  */   
       File fileDir  =   new  File( "./my_searcher/s" ); 
       if(!fileDir.isDirectory())
    	   System.out.println("it isn't a directory");
       if(!fileDir.exists())
    	   System.out.println("file not exit!");
        /*  ����������ļ���λ��  */   
       //File indexDir  =   new  File( " D:\\index " );   
       Analyzer luceneAnalyzer  =   new  StandardAnalyzer();  
       Directory dir = FSDirectory.open(Paths.get("./my_searcher/index"));
       IndexWriterConfig iwc = new IndexWriterConfig(luceneAnalyzer);
       IndexWriter indexWriter  = new IndexWriter(dir, iwc);
       
       File[] textFiles  =  fileDir.listFiles();   
        long  startTime  =   new  Date().getTime();   
          
        // ����document������ȥ    
         for  ( int  i  =   0 ; i  <  textFiles.length; i ++ )  {   
            if  (textFiles[i].isFile()   
                 &&  textFiles[i].getName().endsWith( ".txt" ))  {   
               System.out.println( "File"   +  textFiles[i].getCanonicalPath()   
                        +   "���ڱ�����." );   
               String temp  =  FileReaderAll(textFiles[i].getCanonicalPath(),   
                        "GBK" );   
               System.out.println(temp);   
               Document document  =   new  Document();   
               Field FieldPath  =   new  TextField( "path" , textFiles[i].getPath(),   
                       Field.Store.YES);  
               Field FieldName  =   new  TextField( "name" , textFiles[i].getName(),   
                       Field.Store.YES);
               Field FieldBody  =   new  TextField( "body" , temp, Field.Store.YES);   
               document.add(FieldPath);   
               document.add(FieldName); 
               document.add(FieldBody);   
               indexWriter.addDocument(document);   
           }    
       }    
        // �ɰ�optimize()�����Ƕ����������Ż�    
       // indexWriter.optimize();   
       indexWriter.close();   
          
        // ����һ��������ʱ��    
       long  endTime  =   new  Date().getTime();   
       System.out   
               .println( "�⻨���� "   
                        +  (endTime  -  startTime)   
                        +   " ���������ĵ����ӵ���������ȥ! "   
                        +  fileDir.getPath());  
	}
 
    public   static  String FileReaderAll(String FileName, String charset)   
            throws  IOException  {   
       BufferedReader reader  =   new  BufferedReader( new  InputStreamReader(   
                new  FileInputStream(FileName), charset));   
       String line  =   new  String();   
       String temp  =   new  String();   
          
        while  ((line  =  reader.readLine())  !=   null )  {   
           temp  +=  line;   
       }    
       reader.close();   
        return  temp;   
   } 
}
