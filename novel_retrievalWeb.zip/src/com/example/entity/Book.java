package com.example.entity;

public class Book {
	String id;
	String name;
	String author;
	String publisher;
	String publicTime;
	Float score;
	Integer count;
	String content_brief;
	String author_brief;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getPublicTime() {
		return publicTime;
	}
	public void setPublicTime(String publicTime) {
		this.publicTime = publicTime;
	}

	public Float getScore() {
		return score;
	}
	public void setScore(Float score) {
		this.score = score;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public String getContent_brief() {
		return content_brief;
	}
	public void setContent_brief(String content_brief) {
		this.content_brief = content_brief;
	}
	public String getAuthor_brief() {
		return author_brief;
	}
	public void setAuthor_brief(String author_brief) {
		this.author_brief = author_brief;
	}
	
	
}
