package com.example.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;

import org.hibernate.Session;
import org.hibernate.query.Query;

import com.example.entity.Book;
import com.example.util.SessionHelper;

public class BookDao {
	
	@SuppressWarnings("unchecked")
	public List<Book> queryAll(){
		List<Book> list = null;
		Session session = null;
		try {
		    session= SessionHelper.getSession();
			list = new ArrayList<>();
			String hql = "from Book";
			Query<Book> q = session.createQuery(hql);
			list = q.list();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			session.close();
		}
		return list;
	}

	public Book GetById(String id ){
		Book qa = null;
		Session session = null;
		try {
		    session= SessionHelper.getSession();		    
			qa = session.get(Book.class, id);
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			session.close();
		}
		return qa;
	}
	
	public static void main(String[] args){
		BookDao dao  = new BookDao();
		dao.queryAll();
		Book b =dao.GetById("2");
		System.out.println(b.getName());
		System.out.println(b.getAuthor());
		System.out.println(b.getPublisher());
		System.out.println(b.getScore());
		System.out.println(b.getCount());
		System.out.println(b.getContent_brief());
		System.out.println(b.getAuthor_brief());
	}
}
