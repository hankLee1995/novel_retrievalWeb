package com.example.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.junit.Test;

import com.example.entity.qa_robot_common;
import com.example.util.SessionHelper;

public class qa_commonDao {
	
	public List queryAll(){
		List<qa_robot_common> list = null;
		Session session = null;
		try {
		    session= SessionHelper.getSession();
			list = new ArrayList<>();
			String hql = "from qa_robot_common";
			Query<qa_robot_common> q = session.createQuery(hql);
			list = q.list();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			session.close();
		}
		return list;
	}

	public qa_robot_common GetById(String id ){
		qa_robot_common qa = null;
		Session session = null;
		try {
		    session= SessionHelper.getSession();		    
			qa = session.get(qa_robot_common.class, Integer.parseInt(id));
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			session.close();
		}
		return qa;
	}
	
	public static void main(String[] args){
		qa_commonDao dao  = new qa_commonDao();
		dao.GetById("2");
	}
}
